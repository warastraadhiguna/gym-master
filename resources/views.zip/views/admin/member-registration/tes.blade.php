<div style="text-align: center">
    <div
        style="background-color: rgb(0, 201, 33); font-size: 20px; color: rgb(255, 255, 255); text-align: center; border-radius: 7px;">
        <p style="padding-top: 5px; padding-bottom: 5px;"><b>Member Checked In Successfully</b></p>

    </div>
    <img src="{{ asset('default.png') }}" width="100px" alt="">


    <table class="table" style="margin: auto;">
        <thead>
            <tr>
                <th><b>Full Name</b></th>
                <td>Fernando Herman Pookey</td>
            </tr>
            <tr>
                <th><b>Phone Number</b></th>
                <td>08080808</td>
            </tr>
            <tr>
                <th><b>Nick Name</b></th>
                <td>Nando</td>
            </tr>
        </thead>
    </table>
</div>
