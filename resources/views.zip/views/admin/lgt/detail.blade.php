<div class="col-xl-12">
    <div class="card">
        <div class="card-body">
            <div class="teacher-deatails">
                <h3 class="heading">Trainer Session Detail:</h3>
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col"><b>Check In Date</b></th>
                            {{-- <th scope="col">{{ $xxx->check_in_date }}</th> --}}
                            {{-- @foreach ($xxx as $item)
                                <li>{{ $item->check_in_date }}</li>
                            @endforeach --}}
                        </tr>
                    </thead>
                </table>
            </div>
        </div>
    </div>
</div>
